package com.example.loginregister_ceksehat.ui.chatbot

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.loginregister_ceksehat.adapter.ChatAdapter
import com.example.loginregister_ceksehat.data.response.ChatBotResponse
import com.example.loginregister_ceksehat.data.retrofit.ApiConfig
import com.example.loginregister_ceksehat.databinding.FragmentChatbotBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChatBotFragment : Fragment() {

    private lateinit var binding: FragmentChatbotBinding
    private val chatList = mutableListOf<String>()
    private lateinit var chatAdapter: ChatAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentChatbotBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        chatAdapter = ChatAdapter(chatList)
        binding.recyclerViewChat.adapter = chatAdapter

        binding.sendButton.setOnClickListener {
            val message = binding.messageInput.text.toString()
            if (message.isNotEmpty()) {
                addMessageToChat("User: $message")
                sendChatMessage(message)
                binding.messageInput.text?.clear()

                hideWelcomeTexts()
            }
        }
    }

    private fun sendChatMessage(message: String) {
        val input = mapOf("message" to message)

        val client = ApiConfig.getChatBotApiService().getChatResponse(input)
        client.enqueue(object : Callback<ChatBotResponse> {
            override fun onResponse(
                call: Call<ChatBotResponse>,
                response: Response<ChatBotResponse>
            ) {
                if (response.isSuccessful) {
                    val chatResponse = response.body()?.response
                    chatResponse?.let { addMessageToChat("Bot: $it") }
                }
            }

            override fun onFailure(call: Call<ChatBotResponse>, t: Throwable) {
            }
        })
    }

    private fun addMessageToChat(message: String) {
        chatList.add(message)
        chatAdapter.notifyItemInserted(chatList.size - 1)
        binding.recyclerViewChat.scrollToPosition(chatList.size - 1)
    }

    private fun hideWelcomeTexts() {
        binding.textWelcome1.visibility = View.GONE
        binding.textWelcome2.visibility = View.GONE
        binding.textWelcome3.visibility = View.GONE
    }
}
