package com.example.loginregister_ceksehat.data.retrofit

import com.example.loginregister_ceksehat.data.response.ArtikelResponse
import com.example.loginregister_ceksehat.data.response.ChatBotResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {

    @GET("articles")
    fun getArticles(): Call<List<ArtikelResponse>>

    @POST("chat")
    fun getChatResponse(@Body input: Map<String, String>): Call<ChatBotResponse>
}



