package com.example.loginregister_ceksehat.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.loginregister_ceksehat.data.response.ArtikelResponse
import com.example.loginregister_ceksehat.databinding.ItemArtikelBinding

class ArtikelAdapter(private var listArtikel: List<ArtikelResponse>) :
    RecyclerView.Adapter<ArtikelAdapter.ViewHolder>() {

    fun setList(newList: List<ArtikelResponse>) {
        listArtikel = newList
        notifyDataSetChanged()
    }

    class ViewHolder(private val binding: ItemArtikelBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(artikel: ArtikelResponse) {
            binding.articleTitle.text = artikel.title
            binding.articleDescription.text = artikel.content
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemArtikelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listArtikel[position])
    }

    override fun getItemCount(): Int = listArtikel.size
}
